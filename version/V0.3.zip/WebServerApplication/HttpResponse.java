
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;


/**
 * HttpResponse
 */
public class HttpResponse {
    private Socket socketserver;
    
    HttpResponse(Socket socket){
        this.socketserver = socket;
    }


    
    public void ok(String message){   
         try { 
            OutputStream output = this.socketserver.getOutputStream();
        PrintWriter writer = new PrintWriter(output, true);
        String text = "HTTP/1.0 200 ok";

        writer.println(text);
        System.out.println(text);
        this.socketserver.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
    public void notFound(String message){
      
        try{
            OutputStream output = this.socketserver.getOutputStream();
        PrintWriter writer = new PrintWriter(output, true);
        String text = "HTTP/1.0 404 Not Found";
        writer.println(text);
        System.out.println(text);
        this.socketserver.close();
       
         }catch(IOException e){
            e.printStackTrace();
        }
    }
}