import java.io.IOException;
import java.net.Socket;


public class  RequestProcessor  {


    private Socket socket ; 

     
      RequestProcessor(Socket socket){
        this.socket=socket; 

      }

  


public void process(){
        try { 
            HttpRequest request=  new HttpRequest(socket); 
            request.readClientRequest(socket);
             HttpContext  context= new HttpContext(socket); 
             

           HttpResponse  response =  new HttpResponse(socket); 
            
            if("/".equals(request.getUrl())){
               response.ok("ok");
            }else{
                response.notFound("erreur");  
            }
          
        } 
        catch (Exception e ) {
            e.printStackTrace();
        }


    }
} 
