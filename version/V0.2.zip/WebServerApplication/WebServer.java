import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;




class WebServer{
    private int port;
    
    WebServer(int port){ //construct
        this.port = port;
    }

    public void socketserver(){
        try {
            ServerSocket socketserver = new ServerSocket(port);
            Socket socket = socketserver.accept();
            readRequest(socket);
            sendReponse(socket);
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }


    public void readRequest(Socket socket){
        try {
            InputStream input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            String line = reader.readLine();
            System.out.println(line);
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    public void sendReponse(Socket socket){
        try {
        String strCurrentLine;
        
            OutputStream output = socket.getOutputStream();
        PrintWriter writer = new PrintWriter(output, true);
        StringBuilder text = new StringBuilder("HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n");
        BufferedReader objReader = new BufferedReader(new FileReader("text.html"));
        while ((strCurrentLine = objReader.readLine()) != null) {
            text.append(strCurrentLine).append("\n");
        }
        writer.println(text);
        System.out.println(text);
        socket.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

}